from distutils.core import setup

setup(
	name='funniesttest',
	packages=['funniest'],
	version='1.0',
	description='test',
	author='softmax',
	author_email='softmax.vision@gmail.com',
	url='https://github.com/softmax-vision/funnytest',
	download_url='https://github.com/softmax-vision/funnytest/archive/1.0.tar.gz',
	keywords=['tag1','tag2'],
	classifiers=[]
)
